package lt.viko.eif.d.vaicekauskas.gamestore.Model;

import jakarta.persistence.*;

import java.util.List;

@Entity
public class Order extends Game {

    private @Id @GeneratedValue int id;
    private String orderDate;


    @OneToMany(targetEntity = Game.class, cascade = CascadeType.ALL)
    private List<Game> games;


    @OneToMany(targetEntity = Customer.class, cascade = CascadeType.ALL)
    private List<Customer> customers;
    private String date;

    public Order(){};

    public Order(int id, List<Game> games, List<Customer> customers, String date){
        this.id = id;
        this.games = games;
        this.customers = customers;
        this.date = date;
    }

    public Order(List<Game> games, List<Customer> customers, String date){
        this.games = games;
        this.customers = customers;
        this.date = date;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public List<Game> getGame() {
        return games;
    }

    public void setGame(List<Game> games) {
        this.games = games;
    }

    public List<Customer> getCustomer() {
        return customers;
    }

    public void setCustomer(List<Customer> customers) {
        this.customers = customers;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    @Override
    public String toString(){
        return String.format("Order:\n\t Game: = \n\t%s" + "Customer: \n\t%s" + "Date: %s\n\t",
                this.games,
                this.customers,
                this.date,
                constructGameString(),
                constructCustomerString());
    }

    private String constructGameString(){
        String resultGame = "";
        for(Game games : this.games){
            resultGame += games.toString();
        }
        return resultGame;
    }

    private String constructCustomerString(){
        String resultCustomer = "";
        for(Customer customers : this.customers){
            resultCustomer += customers.toString();
        }
        return resultCustomer;
    }
}
