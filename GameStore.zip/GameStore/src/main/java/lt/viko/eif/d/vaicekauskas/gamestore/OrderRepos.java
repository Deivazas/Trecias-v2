package lt.viko.eif.d.vaicekauskas.gamestore;

import lt.viko.eif.d.vaicekauskas.gamestore.Model.Order;
import org.springframework.data.jpa.repository.JpaRepository;

public interface OrderRepos extends JpaRepository<Order, Long> {

}